const AWS = require('aws-sdk')
const docClient = new AWS.DynamoDB.DocumentClient()
const { v1: uuidv1 } = require('uuid');

exports.handler = async (event, context, callback) => {
  console.error(event.body)
  let workout = JSON.parse(event.body)
  if (workout.id === undefined || workout.id === -1 || workout.id === "-1") {
    console.log('setting id')
    workout["id"] = uuidv1()
  }
  console.error(JSON.stringify(workout))

  let params = { 
    TableName: 'workouts',
    Item: workout
  }

  try {
    data = await docClient.put(params).promise()
    console.log('status: 200')
  } catch (error) {
    console.log('Status code : 400, Error code : ', error.stack)
  }

  return {
    statusCode: 200,
    body: JSON.stringify({"id": "999"}),
    headers: {
      'Access-Control-Allow-Origin': '*'
    }
  }
}

// const validateId = workout => {
//   if (workout.id === undefined){
//     workout.id = uuidv4()
//   }
//   return workout
// }
